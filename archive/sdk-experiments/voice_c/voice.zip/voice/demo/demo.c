#include <stdio.h>
#include <math.h>
#include "voicechanger.h"

#define SAMPLE_RATE 48000

int main()
{
    vc_init();

    vc_set_params(1.3, 1.2);

    PCMFrame20ms input;
    PCMFrame20ms output;

    double phase = 0;

    for (int frame = 0; frame < 500; frame++)
    {
        for (int i = 0; i < VC_FRAME_SAMPLES; i++)
        {
            double freq = 220.0;

            input.data[i] =
                (int16_t)(12000 *
                    sin(2 * 3.1415926 * freq * phase));

            phase += 1.0 / SAMPLE_RATE;

            if (phase >= 1.0)
                phase -= 1.0;
        }

        output = vc_process(input);

        if (frame % 50 == 0)
            printf("frame %d processed\n", frame);
    }

    vc_destroy();

    printf("finished\n");

    return 0;
}